# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['zotero']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'alephclient>=2.3.5,<3.0.0',
 'attrs>=22.1.0,<23.0.0',
 'dataset>=1.5.2,<2.0.0',
 'psycopg2-binary>=2.9.3,<3.0.0',
 'python-dotenv>=0.21.0,<0.22.0',
 'pyzotero>=1.5.5,<2.0.0',
 'watchgod>=0.8.2,<0.9.0']

entry_points = \
{'console_scripts': ['zotero = zotero.zotero:main']}

setup_kwargs = {
    'name': 'zotero',
    'version': '0.1.4',
    'description': '',
    'long_description': '',
    'author': 'Rob Barry',
    'author_email': 'rob.barry@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
